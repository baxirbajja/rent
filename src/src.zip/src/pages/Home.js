import React from "react";
// import myImage1 from "../images/image1.jpg";
import "./Home.css";

const Home = () => {
  return (
    <div className="home-container">
      <div className="welcome-text">
        <h1>Welcome to Us</h1>
      </div>
    </div>
  );
};

export default Home;
